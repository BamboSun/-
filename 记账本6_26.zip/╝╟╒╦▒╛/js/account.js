	// init
	Bmob.initialize("30d9f3f953f38233f702b79d1dd38713", "97083971949beac9a6341ac7748b71f4");
	
	var Record = Bmob.Object.extend("record"); //表名

(function($, owner) {
	var query = new Bmob.Query(Record);
	
	//条件查询该用户所有数据
	owner.queryAllRecord = function(callback) {
		var user = JSON.parse(localStorage.recentlyLoginUser);
		query.equalTo("username", user.account);
		
		query.find({
		  success: function(results) {
		    // alert("共查询到 " + results.length + " 条记录");
//		    // 循环处理查询到的数据
//		    for (var i = 0; i < results.length; i++) {
//		      var object = results[i];
//		      alert(object.id + ' - ' + object.get('username') + ' - ' + object.get('date') +' - '+ object.get('classifytwo') + ' - ' + object.get('money'));
//		    }
			 return callback(results);
		  },
		  error: function(error) {
		    alert("查询失败: " + error.code + " " + error.message);
		  }
		});
	};

	//删除
	owner.deleteRecord = function(id) {
	    query.get(id, {
	      success: function(object) {
	        object.destroy({
	          success: function(deleteObject) {
	          	//alert("delete success");
	          },
	          error: function(deletetest, error) {
	          	alert("sorry, delete fail");
	          }
	        });
	      },
	      error: function(object, error) {
	        alert("查询失败！");
	      }
	    });
   }
	
	
}(mui, window.app = {}));
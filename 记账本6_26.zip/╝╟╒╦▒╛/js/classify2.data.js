var inData = [{
	value: '110000',
	text: '收入',
	children: [{
		value: "110101",
		text: "生活费"
	}, {
		value: "110102",
		text: "奖学金"
	}, {
		value: "110103",
		text: "理财收入"
	}, {
		value: "110103",
		text: "兼职收入"
	}, {
		value: "110104",
		text: "利息收入"
	}]
}]
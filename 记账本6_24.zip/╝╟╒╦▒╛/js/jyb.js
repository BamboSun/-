	// init
	Bmob.initialize("30d9f3f953f38233f702b79d1dd38713", "97083971949beac9a6341ac7748b71f4");
	var Record = Bmob.Object.extend("account_record"); //表名
	var User = Bmob.Object.extend("appuser");  //表名
	
	var record = new Record();

(function($, owner) {
	var user = JSON.parse(localStorage.recentlyLoginUser);
	
	//add record
	function addRecord(recodeInfo) {
		record.save({
		  username: user.account,
		  date: "2018-06-15 14:30:00",
		  classifyone: "食品",
		  classifytwo: "三餐",
 		  money: 18,
 		  attribute:"out"
		}, {
		  success: function(gameScore) {
		    // 添加成功
		    return callback('记一笔成功！');
		  },
		  error: function(gameScore, error) {
		    // 添加失败
		    return callback('记录失败！');
		  }
		});
	}
}(mui, window.app = {}));
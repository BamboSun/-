var outData = [{
	value: '110000',
	text: '食品',
	children: [{
		value: "110101",
		text: "三餐"
	}, {
		value: "110102",
		text: "饮料"
	}, {
		value: "110103",
		text: "水果"
	}, {
		value: "110104",
		text: "零食"
	}]
}, {
	value: '120000',
	text: '交通',
	children: [{
		value: "120101",
		text: "公共交通"
	}, {
		value: "120102",
		text: "自行车"
	}, {
		value: "120103",
		text: "打车租车"
	}]
}, {
	value: '130000',
	text: '娱乐',
	children: [{
		value: "130100",
		text: "电影"
	}, {
		value: "130200",
		text: "KTV"
	}, {
		value: "130300",
		text: "休闲娱乐"
	}, {
		value: "130400",
		text: "运动健身"
	}]
}, {
	value: '140000',
	text: '购物',
	children: [{
		value: "140100",
		text: "衣服裤子"
	}, {
		value: "140200",
		text: "衣帽包包"
	}, {
		value: "140300",
		text: "化妆饰品"
	}, {
		value: "140400",
		text: "美容护肤"
	}, {
		value: "140500",
		text: "日用品"
	}]
}]